This repository contains reference solutions and utility classes for the Flink Training exercises 
on [http://dataartisans.github.io/flink-training](http://dataartisans.github.io/flink-training).
