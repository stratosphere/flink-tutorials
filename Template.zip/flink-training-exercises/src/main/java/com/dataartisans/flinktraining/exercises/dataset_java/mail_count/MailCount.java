/*
 * Copyright 2015 data Artisans GmbH
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dataartisans.flinktraining.exercises.dataset_java.mail_count;

import com.dataartisans.flinktraining.dataset_preparation.MBoxParser;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.tuple.Tuple2;

/**
 * "Mail Count" exercise of the Flink training.
 * The task of the exercise is to count the number of mails sent for each month and email address.
 *
 */
public class MailCount {

	public static void main(String[] args) throws Exception {

		String input = "/YOUR/PATH/TO/flinkMails.gz";

		// obtain an execution environment
		ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();

		// read the "time" and "sender" fields of the input data set (field 2 and 3) as Strings
		DataSet<Tuple2<String, String>> mails =
			env.readCsvFile(input)
				.lineDelimiter(MBoxParser.MAIL_RECORD_DELIM)
				.fieldDelimiter(MBoxParser.MAIL_FIELD_DELIM)
				.includeFields("011")
				.types(String.class, String.class);

		mails
				// ########### PUT YOUR IMPLEMENTATION HERE ###########
				// print the result
				.print();

	}

}
